# Upgrade to Ultraviolet v2.x

## No support for older Bare servers.

In order to more effectively use newer APIs provided by newer implementations of bare-client, support folder older Bare servers has been dropped.

You need to upgrade your Bare server in order to use Ultraviolet.

See the [Bare server node upgrade guide](https://github.com/tomphttp/bare-server-node/blob/master/docs/V2-UPGRADE-GUIDE.md) for upgrading your Bare server.
